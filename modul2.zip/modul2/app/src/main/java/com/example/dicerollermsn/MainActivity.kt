package com.example.dicerollermsn

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Get a reference to the 'roll_button' button
        val rollButton: Button = findViewById(R.id.button)

        //Call rollDice function to set onClickListener
        rollButton.setOnClickListener { rollDice() }
    }

    private fun rollDice() {
        var dice1 = dice1()
        var dice2 = dice2()

        //Get a reference to the dice Image
        val diceImage1: ImageView = findViewById(R.id.imageView)
        val diceImage2: ImageView = findViewById(R.id.imageView2)

        //Update the source of the ImageView
        diceImage1.setImageResource(dice1)
        diceImage2.setImageResource(dice2)
        //Add Conditional so it will create a message based on the conditional
        if (dice1 == dice2) {
            //Show a message based by the conditional above
            Toast.makeText(this,    "Selamat anda dapat dadu double!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Anda belum beruntung!", Toast.LENGTH_SHORT).show()
        }
    }

    //Create a dice that show different number at random
    private fun dice1(): Int {
        // return a random number between 1 to 6 and choose a specific dice image based on the value of the random number
        return when ((1..6).random()) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
    }

    private fun dice2(): Int {
        return when ((1..6).random()) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
    }
}
